﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bCancel = new System.Windows.Forms.Button();
            this.bRefresh = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbNonZero = new System.Windows.Forms.RadioButton();
            this.rbEvenOdd = new System.Windows.Forms.RadioButton();
            this.cbClip = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbTest2 = new System.Windows.Forms.RadioButton();
            this.rbTest1 = new System.Windows.Forms.RadioButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(683, 540);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bCancel
            // 
            this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bCancel.Location = new System.Drawing.Point(10, 234);
            this.bCancel.Name = "bCancel";
            this.bCancel.Size = new System.Drawing.Size(85, 23);
            this.bCancel.TabIndex = 1;
            this.bCancel.Text = "E&xit";
            this.bCancel.UseVisualStyleBackColor = true;
            this.bCancel.Click += new System.EventHandler(this.bClose_Click);
            // 
            // bRefresh
            // 
            this.bRefresh.Location = new System.Drawing.Point(10, 203);
            this.bRefresh.Name = "bRefresh";
            this.bRefresh.Size = new System.Drawing.Size(85, 23);
            this.bRefresh.TabIndex = 0;
            this.bRefresh.Text = "&Refresh";
            this.bRefresh.UseVisualStyleBackColor = true;
            this.bRefresh.Click += new System.EventHandler(this.bRefresh_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbClip);
            this.groupBox1.Controls.Add(this.rbNonZero);
            this.groupBox1.Controls.Add(this.rbEvenOdd);
            this.groupBox1.Location = new System.Drawing.Point(10, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(85, 94);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "&Fill Type";
            // 
            // rbNonZero
            // 
            this.rbNonZero.AutoSize = true;
            this.rbNonZero.Checked = true;
            this.rbNonZero.Location = new System.Drawing.Point(10, 42);
            this.rbNonZero.Name = "rbNonZero";
            this.rbNonZero.Size = new System.Drawing.Size(67, 17);
            this.rbNonZero.TabIndex = 1;
            this.rbNonZero.TabStop = true;
            this.rbNonZero.Text = "NonZero";
            this.rbNonZero.UseVisualStyleBackColor = true;
            this.rbNonZero.Click += new System.EventHandler(this.rbNonZero_Click);
            // 
            // rbEvenOdd
            // 
            this.rbEvenOdd.AutoSize = true;
            this.rbEvenOdd.Location = new System.Drawing.Point(10, 21);
            this.rbEvenOdd.Name = "rbEvenOdd";
            this.rbEvenOdd.Size = new System.Drawing.Size(70, 17);
            this.rbEvenOdd.TabIndex = 0;
            this.rbEvenOdd.Text = "EvenOdd";
            this.rbEvenOdd.UseVisualStyleBackColor = true;
            this.rbEvenOdd.Click += new System.EventHandler(this.rbNonZero_Click);
            // 
            // cbClip
            // 
            this.cbClip.AutoSize = true;
            this.cbClip.Checked = true;
            this.cbClip.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbClip.Location = new System.Drawing.Point(10, 67);
            this.cbClip.Name = "cbClip";
            this.cbClip.Size = new System.Drawing.Size(43, 17);
            this.cbClip.TabIndex = 2;
            this.cbClip.Text = "&Clip";
            this.cbClip.UseVisualStyleBackColor = true;
            this.cbClip.Click += new System.EventHandler(this.rbNonZero_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbTest2);
            this.groupBox2.Controls.Add(this.rbTest1);
            this.groupBox2.Location = new System.Drawing.Point(10, 116);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(85, 73);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "&Test";
            // 
            // rbTest2
            // 
            this.rbTest2.AutoSize = true;
            this.rbTest2.Location = new System.Drawing.Point(10, 42);
            this.rbTest2.Name = "rbTest2";
            this.rbTest2.Size = new System.Drawing.Size(46, 17);
            this.rbTest2.TabIndex = 1;
            this.rbTest2.Text = "Two";
            this.rbTest2.UseVisualStyleBackColor = true;
            this.rbTest2.Click += new System.EventHandler(this.bRefresh_Click);
            // 
            // rbTest1
            // 
            this.rbTest1.AutoSize = true;
            this.rbTest1.Checked = true;
            this.rbTest1.Location = new System.Drawing.Point(10, 21);
            this.rbTest1.Name = "rbTest1";
            this.rbTest1.Size = new System.Drawing.Size(45, 17);
            this.rbTest1.TabIndex = 0;
            this.rbTest1.TabStop = true;
            this.rbTest1.Text = "One";
            this.rbTest1.UseVisualStyleBackColor = true;
            this.rbTest1.Click += new System.EventHandler(this.bRefresh_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 518);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(683, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bCancel;
            this.ClientSize = new System.Drawing.Size(683, 540);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bRefresh);
            this.Controls.Add(this.bCancel);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clipper C# Demo1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bCancel;
        private System.Windows.Forms.Button bRefresh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbNonZero;
        private System.Windows.Forms.RadioButton rbEvenOdd;
        private System.Windows.Forms.CheckBox cbClip;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbTest2;
        private System.Windows.Forms.RadioButton rbTest1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

