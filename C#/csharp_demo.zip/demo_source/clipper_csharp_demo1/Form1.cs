﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Windows.Forms;
using Clipper;

/*******************************************************************************
*                                                                              *
* This the very first stuff I've written in C#, so please accept my apologies  *
* if the coding style is unorthodox. (Angus Johnson)                           *
*                                                                              *
*******************************************************************************/

namespace WindowsFormsApplication1
{

    using TPolygon = List<TDoublePoint>;
    using TPolyPolygon = List<List<TDoublePoint>>;

    public partial class Form1 : Form
    {

        Assembly _assembly;
        Stream polyStream;

        private Bitmap mybitmap;
        private TPolyPolygon subjects;
        private TPolyPolygon clips;

        //---------------------------------------------------------------------
        //---------------------------------------------------------------------

        static private System.Drawing.PointF[] TPolygonToPointFArray(TPolygon pg)
        {
            System.Drawing.PointF[] result = new System.Drawing.PointF[pg.Count];
            for (int i = 0; i < pg.Count; ++i)
            {
                result[i].X = (float)pg[i].X;
                result[i].Y = (float)pg[i].Y;
            }
            return result;
        }
        //---------------------------------------------------------------------

        public Form1()
        {
            InitializeComponent();
            this.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
        }
        //---------------------------------------------------------------------


        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0 && nudOffset.Value < 10) nudOffset.Value += (decimal)0.5;
            else if (e.Delta < 0 && nudOffset.Value > -10) nudOffset.Value -= (decimal)0.5;
        }
        //---------------------------------------------------------------------

        private void bRefresh_Click(object sender, EventArgs e)
        {
            DrawBitmap();
        }
        //---------------------------------------------------------------------

        private void GenerateRandomEllipses(int count)
        {
            subjects.Clear();
            //load map of Australia from resource ...
            _assembly = Assembly.GetExecutingAssembly();
            polyStream = _assembly.GetManifestResourceStream("ClipperCSharpDemo1.australia.bin");
            int len = (int)polyStream.Length;
            byte[] b = new byte[len];
            polyStream.Read(b, 0, len);
            int polyCnt = BitConverter.ToInt32(b, 0);
            int k = 4;
            for (int i = 0; i < polyCnt; ++i)
            {
                int vertCnt = BitConverter.ToInt32(b, k);
                k += 4;
                TPolygon pg = new TPolygon(vertCnt);
                for (int j = 0; j < vertCnt; ++j)
                {
                    float x = BitConverter.ToSingle(b, k) +70;
                    float y = BitConverter.ToSingle(b, k+4);
                    k += 8;
                    pg.Add(new TDoublePoint(x,y));
                }
                subjects.Add(pg);
            }

            clips.Clear();
            Random rand = new Random();
            GraphicsPath path = new GraphicsPath();
            Point pt = new Point();

            for (int i = 0; i < count; ++i)
            {
                int w = pictureBox1.ClientRectangle.Width - 220;
                int h = pictureBox1.ClientRectangle.Height - 140 - statusStrip1.Height;

                pt.X = rand.Next(w) + panel1.Width + 10;
                pt.Y = rand.Next(h) + 30;
                int size = rand.Next(90) + 10;
                path.Reset();
                path.AddEllipse(pt.X, pt.Y, size, size);
                path.Flatten();
                TPolygon clip = new TPolygon(path.PathPoints.Count());
                foreach (PointF p in path.PathPoints)
                    clip.Add(new TDoublePoint(p.X, p.Y));
                clips.Add(clip);
            }
        }
        //---------------------------------------------------------------------

        private TDoublePoint GenerateRandomPoint(int l, int t, int r, int b, Random rand)
        {
            TDoublePoint newPt = new TDoublePoint();
            newPt.X = rand.Next(r / 10) * 10 + l + 10;
            newPt.Y = rand.Next(b / 10) * 10 + t + 10;
            return newPt;
        }
        //---------------------------------------------------------------------

        private void GenerateRandomPolygon(int count)
        {
            Random rand = new Random();
            int l = panel1.Width;
            int t = 0;
            int r = pictureBox1.ClientRectangle.Width - panel1.Width - 20;
            int b = pictureBox1.ClientRectangle.Height - 20 - statusStrip1.Height;

            subjects.Clear();
            clips.Clear();

            TPolygon subj = new TPolygon(count);
            for (int i = 0; i < count; ++i)
                subj.Add(GenerateRandomPoint(l, t, r, b, rand));
            subjects.Add(subj);

            TPolygon clip = new TPolygon(count);
            for (int i = 0; i < count; ++i)
                clip.Add(GenerateRandomPoint(l, t, r, b, rand));
            clips.Add(clip);
        }
        //---------------------------------------------------------------------

        TClipType GetClipType()
        {
            if (rbIntersect.Checked) return TClipType.ctIntersection;
            if (rbUnion.Checked) return TClipType.ctUnion;
            if (rbDifference.Checked) return TClipType.ctDifference;
            else return TClipType.ctXor;
        }
        //---------------------------------------------------------------------

        TPolyFillType GetPolyFillType()
        {
            if (rbNonZero.Checked) return TPolyFillType.pftNonZero;
            else return TPolyFillType.pftEvenOdd;
        }
        //---------------------------------------------------------------------

        private void DrawBitmap(bool justClip = false)
        {
            if (!justClip)
            {
                if (rbTest2.Checked)
                    GenerateRandomEllipses((int)nudCount.Value);
                else
                    GenerateRandomPolygon((int)nudCount.Value);
            }
            Cursor.Current = Cursors.WaitCursor;
            Graphics newgraphic;
            newgraphic = Graphics.FromImage(mybitmap);
            newgraphic.SmoothingMode = SmoothingMode.AntiAlias;
            newgraphic.Clear(Color.WhiteSmoke);
            Pen myPen = new Pen(Color.LightSlateGray, (float)1.5);
            SolidBrush myBrush = new SolidBrush(Color.FromArgb(16, Color.Blue));
            
            GraphicsPath path = new GraphicsPath();
            if (rbNonZero.Checked) path.FillMode = FillMode.Winding;

            foreach (TPolygon pg in subjects)
            {
                PointF[] pts = TPolygonToPointFArray(pg);
                path.AddPolygon(pts);
                pts = null;
            }
            newgraphic.FillPath(myBrush, path);
            newgraphic.DrawPath(myPen, path);
            path.Reset();
            if (rbNonZero.Checked) path.FillMode = FillMode.Winding;
            foreach (TPolygon pg in clips)
            {
                PointF[] pts = TPolygonToPointFArray(pg);
                path.AddPolygon(pts);
                pts = null;
            }
            myPen.Color = Color.LightSalmon;
            myBrush.Color = Color.FromArgb(16, Color.Red);
            newgraphic.FillPath(myBrush, path);
            newgraphic.DrawPath(myPen, path);

            //do the clipping ...
            if (clips.Count > 0 && !rbNone.Checked)
            {
                TPolyPolygon solution = new TPolyPolygon();
                Stopwatch sw = new Stopwatch();
                sw.Start();
                TClipper c = new TClipper();
                c.AddPolyPolygon(subjects, TPolyType.ptSubject);
                c.AddPolyPolygon(clips, TPolyType.ptClip);
                c.Execute(GetClipType(), solution, GetPolyFillType(), GetPolyFillType());
                sw.Stop();
                double elapsedTime = sw.ElapsedMilliseconds;
                myBrush.Color = Color.Black;
                Font arialFont = new Font("Arial", 10);
                path.Reset();
                path.FillMode = FillMode.Winding;
                //or for something fancy ...
                if (nudOffset.Value != 0)
                    solution = TClipper.OffsetPolygons(solution, (double)nudOffset.Value);
                foreach (TPolygon pg in solution)
                {
                    PointF[] pts = TPolygonToPointFArray(pg);
                    if (pts.Count() > 2)
                      path.AddPolygon(pts);
                    pts = null;
                }
                myBrush.Color = Color.FromArgb(128, Color.Yellow);
                myPen.Color = Color.Black;
                newgraphic.FillPath(myBrush, path);
                newgraphic.DrawPath(myPen, path);
            }
            pictureBox1.Image = mybitmap;
            newgraphic.Dispose();
            Cursor.Current = Cursors.Default;
        }
        //---------------------------------------------------------------------

        //private void SavePolygons(string filename)
        //{
        //    StreamWriter s = File.CreateText(filename);
        //    s.WriteLine("Subjects = {0:0}", subjects.Count);
        //    foreach (TPolygon p in subjects)
        //    {
        //        s.WriteLine("{0:0}", p.Count);
        //        foreach (TDoublePoint dp in p)
        //        {
        //            s.WriteLine("{0:0.0000}, {1:0.0000},", dp.X, dp.Y);
        //        }
        //    }

        //    s.WriteLine("Clips = {0:0}", clips.Count);
        //    foreach (TPolygon p in clips)
        //    {
        //        s.WriteLine("{0:0}", p.Count);
        //        foreach (TDoublePoint dp in p)
        //        {
        //            s.WriteLine("{0:0.0000}, {1:0.0000},", dp.X, dp.Y);
        //        }
        //    }
        //    s.Close();
        //}
        //---------------------------------------------------------------------

        private void Form1_Load(object sender, EventArgs e)
        {
            mybitmap = new Bitmap(
                pictureBox1.ClientRectangle.Width,
                pictureBox1.ClientRectangle.Height,
                PixelFormat.Format32bppArgb);

            subjects = new TPolyPolygon(); 
            clips = new TPolyPolygon();
            DrawBitmap();
            toolStripStatusLabel1.Text =
                "Tip: Use the mouse-wheel (or +,-,0) to adjust the offset of the solution polygons.";
        }
        //---------------------------------------------------------------------

        private void bClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        //---------------------------------------------------------------------

        private void Form1_Resize(object sender, EventArgs e)
        {
            mybitmap.Dispose();
            mybitmap = new Bitmap(
                pictureBox1.ClientRectangle.Width,
                pictureBox1.ClientRectangle.Height,
                PixelFormat.Format32bppArgb);
            pictureBox1.Image = mybitmap;
            DrawBitmap();
        }
        //---------------------------------------------------------------------

        private void rbNonZero_Click(object sender, EventArgs e)
        {
            DrawBitmap(true);
        }
        //---------------------------------------------------------------------

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case (Keys)27:
                    this.Close();
                    return;
                case Keys.F1:
                    MessageBox.Show(this.Text + "\nby Angus Johnson\nCopyright © 2010",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    e.Handled = true;
                    return;
                case (Keys)187:
                case Keys.Add:
                    if (nudOffset.Value == 10) return;
                    nudOffset.Value += (decimal)0.5;
                    e.Handled = true;
                    break;
                case (Keys)189:
                case Keys.Subtract:
                    if (nudOffset.Value == -10) return;
                    nudOffset.Value -= (decimal)0.5;
                    e.Handled = true;
                    break;
                case Keys.NumPad0:
                case Keys.D0:
                    if (nudOffset.Value == 0) return;
                    nudOffset.Value = (decimal)0;
                    e.Handled = true;
                    break;
                default: return;
            }
            
        }
        //---------------------------------------------------------------------

        private void nudCount_ValueChanged(object sender, EventArgs e)
        {
            DrawBitmap();
        }
        //---------------------------------------------------------------------

        private void rbTest1_Click(object sender, EventArgs e)
        {
            if (rbTest1.Checked)
                lblCount.Text = "Vertex &Count:";
            else
                lblCount.Text = "Ellipse &Count:";
            DrawBitmap();
        }
        //---------------------------------------------------------------------
        //---------------------------------------------------------------------

    }
}
