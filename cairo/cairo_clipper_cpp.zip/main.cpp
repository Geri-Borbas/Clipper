//---------------------------------------------------------------------------

#include <windows.h>
#pragma hdrstop

#include "clipper.hpp"
#include "cairo.h"
#include "cairo-win32.h"
#include "cairo_clipper.hpp"
//---------------------------------------------------------------------------

LPCTSTR ClsName = "CairoApp";
LPCTSTR WndName = "A Simple Cairo Clipper Demo";

LRESULT CALLBACK WndProcedure(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

#pragma argsused
WINAPI _tWinMain(HINSTANCE hInstance,
  HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
  MSG        Msg;
  HWND       hWnd;
  WNDCLASSEX WndClsEx;

  // Create the application window
  WndClsEx.cbSize        = sizeof(WNDCLASSEX);
  WndClsEx.style         = CS_HREDRAW | CS_VREDRAW;
  WndClsEx.lpfnWndProc   = WndProcedure;
  WndClsEx.cbClsExtra    = 0;
  WndClsEx.cbWndExtra    = 0;
  WndClsEx.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
  WndClsEx.hCursor       = LoadCursor(NULL, IDC_ARROW);
  WndClsEx.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  WndClsEx.lpszMenuName  = NULL;
  WndClsEx.lpszClassName = ClsName;
  WndClsEx.hInstance     = hInstance;
  WndClsEx.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

  // Register the application
  RegisterClassEx(&WndClsEx);

  // Create the window object
  hWnd = CreateWindow(ClsName, WndName, WS_OVERLAPPEDWINDOW,
    CW_USEDEFAULT, CW_USEDEFAULT, 400, 300,
    NULL, NULL, hInstance, NULL);
  if( !hWnd ) return 0;

  ShowWindow(hWnd, SW_SHOWNORMAL);
  UpdateWindow(hWnd);

  while( GetMessage(&Msg, NULL, 0, 0) )
  {
     TranslateMessage(&Msg);
     DispatchMessage(&Msg);
  }
  return Msg.wParam;
}
//------------------------------------------------------------------------------

void OnPaint(HDC dc)
{
  cairo_surface_t* surface = cairo_win32_surface_create(dc);
  cairo_t* cr = cairo_create(surface);

  cairo_set_fill_rule(cr, CAIRO_FILL_RULE_WINDING);
  cairo_set_line_width (cr, 2.0);

  clipper::Clipper clpr;    //clipper class
  clipper::TPolyPolygon pg; //std::vector for polygon(s) storage

  //create a circular pattern, add the path to clipper and then draw it ...
  cairo_arc(cr, 170,110,70,0,2*3.1415926);
  cairo_close_path(cr);
  cairo_to_clipper(cr, pg);
  clpr.AddPolyPolygon(pg, clipper::ptSubject);
  cairo_set_source_rgba(cr, 0, 0, 1, 0.5);
  cairo_fill_preserve (cr);
  cairo_set_source_rgba(cr, 0, 0, 0, 0.5);
  cairo_stroke (cr);

  //draw a star and another circle, add them to clipper and draw ...
  cairo_move_to(cr, 60,110);
  cairo_line_to (cr, 240,70);
  cairo_line_to (cr, 110,210);
  cairo_line_to (cr, 140,25);
  cairo_line_to (cr, 230,200);
  cairo_close_path(cr);
  cairo_new_sub_path(cr);
  cairo_arc(cr, 190,50,20,0,2*3.1415926);
  cairo_close_path(cr);
  cairo_to_clipper(cr, pg);
  clpr.AddPolyPolygon(pg, clipper::ptClip);
  cairo_set_source_rgba(cr, 1, 0, 0, 0.5);
  cairo_fill_preserve (cr);
  cairo_set_source_rgba(cr, 0, 0, 0, 0.5);
  cairo_stroke (cr);

  clpr.Execute(clipper::ctIntersection, pg,
    clipper::pftNonZero, clipper::pftNonZero); //ie using winding fill rule
  //now do something fancy with the returned polygons ...
  pg = clipper::OffsetPolygons(pg, -5);

  //finally copy the clipped path back to the cairo context and draw it ...
  clipper_to_cairo(pg, cr);
  cairo_set_source_rgba(cr, 1, 1, 0, 1);
  cairo_fill_preserve (cr);
  cairo_set_source_rgba(cr, 0, 0, 0, 1);
  cairo_stroke (cr);

  cairo_destroy (cr);
  cairo_surface_destroy (surface);

}
//------------------------------------------------------------------------------

LRESULT CALLBACK WndProcedure(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    HDC Handle;

    switch(Msg)
    {
      case WM_DESTROY:
        PostQuitMessage(WM_QUIT);
        return 0;

      case WM_PAINT:
        Handle = BeginPaint(hWnd, &ps);
        OnPaint(Handle);
        EndPaint(hWnd, &ps);
        return 0;

      default:
          return DefWindowProc(hWnd, Msg, wParam, lParam);
    }
}
//---------------------------------------------------------------------------

