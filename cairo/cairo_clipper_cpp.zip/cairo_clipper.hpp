/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Version   :  0.50                                                            *
* Date      :  3 November 2010                                                 *
* Copyright :  Angus Johnson                                                   *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *                                                                              *
*******************************************************************************/

#pragma once
#ifndef cairo_clipper_hpp
#define cairo_clipper_hpp

#include "cairo.h"
#include "clipper.hpp"

void cairo_to_clipper(cairo_t* cr, clipper::TPolyPolygon &pg);
void clipper_to_cairo(clipper::TPolyPolygon &pg, cairo_t* cr);

#endif
