/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Version   :  0.50                                                            *
* Date      :  3 November 2010                                                 *
* Copyright :  Angus Johnson                                                   *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *                                                                              *
*******************************************************************************/

#include "cairo.h"
#include "cairo_clipper.hpp"
#include "clipper.hpp"

using namespace clipper;

void cairo_to_clipper(cairo_t* cr, TPolyPolygon &pg)
{
  pg.clear();
  cairo_path_t* path = cairo_copy_path_flat(cr);
  int poly_count = 0;
  for (int i = 0; i < path->num_data; i += path->data[i].header.length)
    if( path->data[i].header.type == CAIRO_PATH_CLOSE_PATH) poly_count++;
  pg.resize(poly_count);
  int i = 0, pc = 0;
  while (pc < poly_count)
  {
    int vert_count = 1;
    int j = i;
    while(j < path->num_data &&
      path->data[j].header.type != CAIRO_PATH_CLOSE_PATH)
    {
      if (path->data[j].header.type == CAIRO_PATH_LINE_TO) vert_count++;
      j += path->data[j].header.length;
    }
    pg[pc].resize(vert_count);
    if (path->data[i].header.type != CAIRO_PATH_MOVE_TO) {
      pg.resize(pc);
      break;
    }
    pg[pc][0].X = path->data[i+1].point.x;
    pg[pc][0].Y = path->data[i+1].point.y;
    i += path->data[i].header.length;

    j = 1;
    while(j < vert_count && i < path->num_data &&
      path->data[i].header.type == CAIRO_PATH_LINE_TO){
      pg[pc][j].X = path->data[i+1].point.x;
      pg[pc][j].Y = path->data[i+1].point.y;
      j++;
      i += path->data[i].header.length;
    }
    pc++;
    i += path->data[i].header.length;
  }
  cairo_path_destroy(path);
}
//------------------------------------------------------------------------------

void clipper_to_cairo(TPolyPolygon &pg, cairo_t* cr)
{
  for (unsigned i = 0; i < pg.size(); ++i)
  {
    unsigned sz = pg[i].size();
    if (sz < 3) continue;
    cairo_new_sub_path(cr);
    for (unsigned j = 0; j < sz; ++j)
      cairo_line_to(cr, pg[i][j].X, pg[i][j].Y);
    cairo_close_path(cr);
  }
}
//------------------------------------------------------------------------------


